
common_func1<-function(){
  "I use this function daily"
}

common_func2<-function(){
  "I dislike flooding my main script"
}

common_data<-c("This is a string vector.", "I can", "call data", "in other script","as well")